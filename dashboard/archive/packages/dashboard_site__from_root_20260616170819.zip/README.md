# Dashboard（GitHub Pages）

本仓库用于通过 GitHub Pages 发布仪表盘静态文件（任意设备可访问）。

## 入口
- 站点根目录：`index.html`
- 月度：`/monthly/`
- 周度：`/weekly/`
- 日度：`/daily/`
- 历史归档：`/archive/`

## 发布说明（在 GitHub 上设置）
在仓库 Settings → Pages：
- Source: Deploy from a branch
- Branch: `main` / Folder: `/ (root)`

